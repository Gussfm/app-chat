package br.com.tech.chatapp.listeners;


import br.com.tech.chatapp.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
